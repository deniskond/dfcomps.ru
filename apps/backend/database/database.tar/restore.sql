--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.3 (Debian 15.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dfcomps;
--
-- Name: dfcomps; Type: DATABASE; Schema: -; Owner: user
--

CREATE DATABASE dfcomps WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE dfcomps OWNER TO "user";

\connect dfcomps

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dfcomps; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA dfcomps;


ALTER SCHEMA dfcomps OWNER TO pg_database_owner;

--
-- Name: SCHEMA dfcomps; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA dfcomps IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: dfcomps; Owner: user
--

CREATE TABLE dfcomps.users (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    password character varying(256) NOT NULL
);


ALTER TABLE dfcomps.users OWNER TO "user";

--
-- Data for Name: users; Type: TABLE DATA; Schema: dfcomps; Owner: user
--

COPY dfcomps.users (id, name, password) FROM stdin;
\.
COPY dfcomps.users (id, name, password) FROM '$$PATH$$/3343.dat';

--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: dfcomps; Owner: user
--

ALTER TABLE ONLY dfcomps.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--


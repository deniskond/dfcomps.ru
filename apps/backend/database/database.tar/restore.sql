--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg120+1)
-- Dumped by pg_dump version 15.3 (Debian 15.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dfcomps;
--
-- Name: dfcomps; Type: DATABASE; Schema: -; Owner: user
--

CREATE DATABASE dfcomps WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE dfcomps OWNER TO "user";

\connect dfcomps

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dfcomps; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA dfcomps;


ALTER SCHEMA dfcomps OWNER TO pg_database_owner;

--
-- Name: SCHEMA dfcomps; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA dfcomps IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth; Type: TABLE; Schema: dfcomps; Owner: user
--

CREATE TABLE dfcomps.auth (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    password character varying(256) NOT NULL
);


ALTER TABLE dfcomps.auth OWNER TO "user";

--
-- Name: auth_id_seq; Type: SEQUENCE; Schema: dfcomps; Owner: user
--

CREATE SEQUENCE dfcomps.auth_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dfcomps.auth_id_seq OWNER TO "user";

--
-- Name: auth_id_seq; Type: SEQUENCE OWNED BY; Schema: dfcomps; Owner: user
--

ALTER SEQUENCE dfcomps.auth_id_seq OWNED BY dfcomps.auth.id;


--
-- Name: user; Type: TABLE; Schema: dfcomps; Owner: user
--

CREATE TABLE dfcomps."user" (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    password character varying(256) NOT NULL
);


ALTER TABLE dfcomps."user" OWNER TO "user";

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: dfcomps; Owner: user
--

CREATE SEQUENCE dfcomps.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dfcomps.user_id_seq OWNER TO "user";

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: dfcomps; Owner: user
--

ALTER SEQUENCE dfcomps.user_id_seq OWNED BY dfcomps."user".id;


--
-- Name: auth id; Type: DEFAULT; Schema: dfcomps; Owner: user
--

ALTER TABLE ONLY dfcomps.auth ALTER COLUMN id SET DEFAULT nextval('dfcomps.auth_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: dfcomps; Owner: user
--

ALTER TABLE ONLY dfcomps."user" ALTER COLUMN id SET DEFAULT nextval('dfcomps.user_id_seq'::regclass);


--
-- Data for Name: auth; Type: TABLE DATA; Schema: dfcomps; Owner: user
--

COPY dfcomps.auth (id, name, password) FROM stdin;
\.
COPY dfcomps.auth (id, name, password) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: dfcomps; Owner: user
--

COPY dfcomps."user" (id, name, password) FROM stdin;
\.
COPY dfcomps."user" (id, name, password) FROM '$$PATH$$/3356.dat';

--
-- Name: auth_id_seq; Type: SEQUENCE SET; Schema: dfcomps; Owner: user
--

SELECT pg_catalog.setval('dfcomps.auth_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: dfcomps; Owner: user
--

SELECT pg_catalog.setval('dfcomps.user_id_seq', 1, false);


--
-- Name: auth PK_7e416cf6172bc5aec04244f6459; Type: CONSTRAINT; Schema: dfcomps; Owner: user
--

ALTER TABLE ONLY dfcomps.auth
    ADD CONSTRAINT "PK_7e416cf6172bc5aec04244f6459" PRIMARY KEY (id);


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: dfcomps; Owner: user
--

ALTER TABLE ONLY dfcomps."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

